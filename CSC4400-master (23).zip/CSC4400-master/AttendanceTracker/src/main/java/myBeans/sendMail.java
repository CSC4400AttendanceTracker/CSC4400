/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myBeans;

import java.util.*;
import java.util.Properties.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.mail.Transport.*;
import javax.mail.Message.*;
import javax.mail.Session.*;
import javax.mail.internet.MimeMessage.*;
import javax.mail.PasswordAuthentication.*;


/**
 *
 * @author glane
 */
public class sendMail {
  public void sendEmail(){
    String host="smtp.gmail.com";
     String to = "laneproperties71@gmail.com";
     String from = "geraldlane95@gmail.com";
     
     
     
   Properties properties = System.getProperties();

        // Setup mail server
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
     
   Session session = Session.getInstance(properties,  
    new javax.mail.Authenticator() {  
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {  
    return new PasswordAuthentication("geraldlane95@gmail.com","Shadowlt1");  
      }  
    });  
    
    
    session.setDebug(true);
    
      try{
     MimeMessage message_1 = new MimeMessage(session); 
     message_1.setFrom(new InternetAddress(from));  
     message_1.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
     message_1.setSubject("test");  
     message_1.setText("TESTTTT");  
       
    //send the message  
     Transport.send(message_1);  
  
      
   
        
      }catch (MessagingException mex) {
            mex.printStackTrace();
      }
     
    
  
  
  }
  
  public static void main(String[] args) {
     String host="smtp.gmail.com";
     String to = "laneproperties71@gmail.com";
     String from = "geraldlane95@gmail.com";
     
     
     
   Properties properties = System.getProperties();

        // Setup mail server
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
     
   Session session = Session.getInstance(properties,  
    new javax.mail.Authenticator() {  
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {  
    return new PasswordAuthentication("geraldlane95@gmail.com","Shadowlt1");  
      }  
    });  
    
    
    session.setDebug(true);
    
      try{
     MimeMessage message_1 = new MimeMessage(session); 
     message_1.setFrom(new InternetAddress(from));  
     message_1.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
     message_1.setSubject("test");  
     message_1.setText("TESTTTT");  
       
    //send the message  
     Transport.send(message_1);  
  
     System.out.println("message sent successfully...");  
   
        
      }catch (MessagingException mex) {
            mex.printStackTrace();
      }
     
    
  }
}
