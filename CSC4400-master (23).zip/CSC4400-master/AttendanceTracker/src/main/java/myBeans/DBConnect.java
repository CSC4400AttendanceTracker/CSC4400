/*
 * This contains the business logic to connect to the database
 *
 * @author nmahadev
 */
package myBeans;

import java.sql.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.mail.Transport.*;
import javax.mail.Message.*;
import javax.mail.Session.*;
import javax.mail.internet.MimeMessage.*;

public class DBConnect {

  // driver and connection string variables
  private final String driver = "com.mysql.jdbc.Driver";
  //private final String url = "jdbc:mysql://localhost:3306/attendance_tracker";
  private final String url = "jdbc:mysql://localhost:3306/#mysql50#CSC4400-master";
  private final String user = "mahadev";
  private final String pwd = "mahadev";

  // JDBC variables and methods
  private Connection conn = null;           // creates the pipeline 
  private Statement stm = null;
  private PreparedStatement pstm = null;
  private ResultSet rst = null;             // returns table of query
  private ResultSetMetaData rsmd = null;    // returns the structure information of the table

  // Utility Methods
  private String openDB() {
    try {
      Class.forName(driver);
      conn = DriverManager.getConnection(url, user, pwd);
      stm = conn.createStatement();
    } catch (Exception e) {
      return e.getMessage();
    }
    return "Opened";
  }

  private String closeDB() {
    try {
      stm.close();
      conn.close();
    } catch (Exception e) {
      return e.getMessage();
    }
    return "Closed";
  }

  public String isValid(String sql) {
    String message = openDB();
    if (message.equals("Opened")) {
      int count = 0;
      try {
        rst = stm.executeQuery(sql);
        while (rst.next()) {
          count++;
        }
      } catch (Exception e) {
        message = e.getMessage();
      }
      if (count != 0) {
        message = "Login Successful";
      } else {
        message = "Login Failed";
      }
      closeDB();
    }
    return message;
  }

  public int getLastNamesCount(String sql) {
    String message = openDB();
    int count = 0;
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        while (rst.next()) {
          count++;
        }
        message = closeDB();
      } catch (Exception ex) {
        return 0;
      }
    }
    return count;
  }

  public int getLastNum(String sql) {
    String message = openDB();
    int count = 0;
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        if (rst.last()) {
          count = Integer.parseInt(rst.getString(1));
        }
        message = closeDB();
      } catch (Exception ex) {
        return -1;
      }
    }
    return count;
  }

  // APIs connect database
  public String insertData(String sql) {
    String message = openDB();

    if (message.equals("Opened")) {
      try {
        stm.executeUpdate(sql);
        message = "Success";
      } catch (Exception e) {
        return e.getMessage();
      }
      message = "Update Successful";
    }
    closeDB();
    return message;
  }

  public String getUserIDFromUserName(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        if (count == 1 && rst.next()) {
          result = rst.getString(1);
        } else {
          result = "NONE";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }

  public String getUserType(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        if (count == 1 && rst.next()) {
          result = rst.getString(1);
        } else {
          result = "NONE";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }

  public String htmlAddCourseList(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        //result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp\">";
        // create data rows
        while (rst.next()) {
          result += "<a class=\"courseListLink\" href=\"addCourseAction.jsp";
          for (int i = 0; i < count; i++) {
            if (i == 0) {
              result += "?value=" + rst.getString(i + 1) + "\">";
            } else if (i == 5) {
              result += " S" + rst.getString(i + 1) + " \n";
            } else if (i == 7) {
              result += " " + rst.getString(i + 1) + " to \n";
            } else {
              result += " " + rst.getString(i + 1) + " \n";
            }
          }
          result += "</a>\n";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
   public String htmlEnrollCourseList(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        //result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp\">";
        // create data rows
        while (rst.next()) {
          result += "<a class=\"courseListLink\" href=\"studentEnrollAction.jsp";
          for (int i = 0; i < count; i++) {
            if (i == 0) {
              result += "?value=" + rst.getString(i + 1) + "\">";
            } else if (i == 5) {
              result += " S" + rst.getString(i + 1) + " \n";
            } else if (i == 7) {
              result += " " + rst.getString(i + 1) + " to \n";
            } else {
              result += " " + rst.getString(i + 1) + " \n";
            }
          }
          result += "</a>\n";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
  public String htmlRemoveCourseList(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        //result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp\">";
        // create data rows
        while (rst.next()) {
          result += "<a class=\"courseListLink\" href=\"removeCourseAction.jsp";
          for (int i = 0; i < count; i++) {
            if (i == 0) {
              result += "?value=" + rst.getString(i + 1) + "\">";
            } else if (i == 5) {
              result += " S" + rst.getString(i + 1) + " \n";
            } else if (i == 7) {
              result += " " + rst.getString(i + 1) + " to \n";
            } else {
              result += " " + rst.getString(i + 1) + " \n";
            }
          }
          result += "</a>\n";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
   public String htmlSRemoveCourseList(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        //result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp\">";
        // create data rows
        while (rst.next()) {
          result += "<a class=\"courseListLink\" href=\"sRemoveCourseAction.jsp";
          for (int i = 0; i < count; i++) {
            if (i == 0) {
              result += "?value=" + rst.getString(i + 1) + "\">";
            } else if (i == 5) {
              result += " S" + rst.getString(i + 1) + " \n";
            } else if (i == 7) {
              result += " " + rst.getString(i + 1) + " to \n";
            } else {
              result += " " + rst.getString(i + 1) + " \n";
            }
          }
          result += "</a>\n";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
  public String htmlCourseList(String sql) {
    String result = "";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        //result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp\">";
        // create data rows
        while (rst.next()) {
          result += "<a class=\"courseListLink\" href=\"courseViewOverall.jsp";
          for (int i = 0; i < count; i++) {
            if (i == 0) {
              result += "?value=" + rst.getString(i + 1) + "\">";
            } else if (i == 5) {
              result += " S" + rst.getString(i + 1) + " \n";
            } else if (i == 7) {
              result += " " + rst.getString(i + 1) + " to \n";
            } else {
              result += " " + rst.getString(i + 1) + " \n";
            }
          }
          result += "</a>\n";
        }
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }

  public String htmlTable(String sql) {
    String result = "<table>\n";
    String message = openDB();
    if (message.equals("Opened")) {
      try {
        rst = stm.executeQuery(sql);
        rsmd = rst.getMetaData();
        int count = rsmd.getColumnCount();
        // create column headings
        result += "<tr>\n";
        for (int i = 0; i < count; i++) {
          result += "<th>" + rsmd.getColumnName(i + 1) + "</th>\n";
        }
        result += "</tr>\n";
        // create data rows
        while (rst.next()) {
          result += "<tr>\n";
          for (int i = 0; i < count; i++) {
            result += "<td>" + rst.getString(i + 1) + "</td>\n";
          }
          result += "</tr>\n";
        }
        result += "</table>\n";
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
    public String sendMail(String sql) {
     String host="smtp.gmail.com";
     String to = "laneproperties71@gmail.com";
     String from = "geraldlane95@gmail.com";
     String result = "";
     String message = openDB();
     Properties props = new Properties();  
   props.put("mail.smtp.host",host);  
   props.put("mail.smtp.auth", "true");  
   Properties properties = System.getProperties();

        // Setup mail server
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
     
   Session session = Session.getDefaultInstance(props,  
    new javax.mail.Authenticator() {  
      protected PasswordAuthentication getPasswordAuthentication() {  
    return new PasswordAuthentication("geraldlane95@gmail.com","Shadowlt1");  
      }  
    });  
    //https://www.javatpoint.com/example-of-sending-email-using-java-mail-api
    
    if (message.equals("Opened")) {
      try {
        javax.mail.internet.MimeMessage message_1 = new MimeMessage(session); 
     message_1.setFrom(new InternetAddress(from));  
     message_1.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
     message_1.setSubject("javatpoint");  
     message_1.setText("This is simple program of sending email using JavaMail API");  
       
    //send the message  
     Transport.send(message_1);  
  
     System.out.println("message sent successfully...");  
   
        
       
        message = closeDB();
        return result;
      } catch (Exception e) {
        return e.getMessage();
      }
    } else {
      return message;
    }
  }
}
